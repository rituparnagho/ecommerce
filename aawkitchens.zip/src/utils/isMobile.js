
export const isMobile = () => {
    return window.innerWidth < 768; 
  };
  