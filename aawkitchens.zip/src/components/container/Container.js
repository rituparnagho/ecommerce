import React from 'react'
import "./Container.css"

const Container = () => {
  return (
    <div className='header-content'>
        <div class="desktop-logo desktop-logo-all">
          <a
            class="logo"
            href="https://aawkitchens.com/"
            title=""
            aria-label="store logo"
            ><img
              src="https://prod.aaw.com/media/logo/stores/13/logo-512.png"
              title=""
              alt=""
              width="170"
          /></a>
        </div>
    </div>
  )
}

export default Container