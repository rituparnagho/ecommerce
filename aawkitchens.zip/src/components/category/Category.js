import React from 'react'
import "./Category.css"

const Category = () => {
  return (
    <div className='main'>
        <div className='category-group' style={{marginLeft:"30px"}}>Products</div>
        <div className='category-group'>Brands</div>
        <div className='cat-bos'><img src='https://static.aawweb.com/media/theme/kitchens/images/bosch_logo_1.png' alt=''/></div>
        <div className='cat-nol'><img src='https://static.aawweb.com/media/wysiwyg/kitchens/nolte.svg' alt=''/></div>
        <div className='cat-del'>Deals</div>
        <div className='category-group'>Gift Card</div>
        <div className='category-group'>After Sales Service Request</div>
    </div>
  )
}

export default Category